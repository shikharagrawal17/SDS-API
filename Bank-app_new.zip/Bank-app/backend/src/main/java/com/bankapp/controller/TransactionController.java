package com.bankapp.controller;

import com.bankapp.model.Transaction;
import com.bankapp.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/transactions")
public class TransactionController {

    @Autowired
    private TransactionService transactionService;

    @PostMapping("/transfer")
    public Transaction transfer(@RequestParam String fromAccount, @RequestParam String toAccount, @RequestParam double amount) {
        return transactionService.transfer(fromAccount, toAccount, amount);
    }

    @GetMapping("/history/{accountNumber}")
    public List<Transaction> getHistory(@PathVariable String accountNumber) {
        return transactionService.getUserTransactions(accountNumber);
    }
}
