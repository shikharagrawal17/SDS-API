package com.bankapp.service;

import com.bankapp.model.Transaction;
import com.bankapp.model.User;
import com.bankapp.repository.TransactionRepository;
import com.bankapp.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class TransactionService {

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private UserRepository userRepository;

    public Transaction transfer(String fromAccount, String toAccount, double amount) {
        User sender = userRepository.findByAccountNumber(fromAccount);
        User recipient = userRepository.findByAccountNumber(toAccount);

        if (sender == null || recipient == null) {
            throw new RuntimeException("Account not found");
        }

        if (sender.getBalance() < amount) {
            throw new RuntimeException("Insufficient funds");
        }

        // Deduct from sender and add to recipient
        sender.setBalance(sender.getBalance() - amount);
        recipient.setBalance(recipient.getBalance() + amount);
        userRepository.save(sender);
        userRepository.save(recipient);

        // Create the transaction record
        Transaction transaction = new Transaction();
        transaction.setFromAccount(fromAccount);
        transaction.setToAccount(toAccount);
        transaction.setAmount(amount);
        transaction.setType("TRANSFER");
        transaction.setTimestamp(new Date().toString());

        return transactionRepository.save(transaction);
    }

    public List<Transaction> getUserTransactions(String accountNumber) {
        return transactionRepository.findByFromAccountOrToAccount(accountNumber, accountNumber);
    }
}
