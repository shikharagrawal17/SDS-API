package com.bankapp.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "transactions")
public class Transaction {

    @Id
    private String id;
    private String fromAccount;
    private String toAccount;
    private double amount;
    private String type;  // e.g., TRANSFER
    private String timestamp;

    // Getters and setters
}
