
const transactionService = {
  getHistory: async (username) => {
    const token = localStorage.getItem('token');
    const response = await fetch(`/transactions/history/${username}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response.json();
  },
};

export default transactionService;
