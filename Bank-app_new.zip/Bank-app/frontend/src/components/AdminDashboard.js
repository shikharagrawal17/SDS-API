
import React from 'react';

const AdminDashboard = () => {
  return (
    <div>
      <h2>Admin Dashboard</h2>
      <p>Manage users and transactions</p>
    </div>
  );
};

export default AdminDashboard;
