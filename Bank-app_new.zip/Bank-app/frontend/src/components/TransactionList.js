
import React, { useEffect, useState } from 'react';
import transactionService from '../services/transactionService';

const TransactionList = () => {
  const [transactions, setTransactions] = useState([]);

  useEffect(() => {
    const username = "testUser";  // Replace with real logged-in user
    transactionService.getHistory(username).then(data => {
      setTransactions(data);
    });
  }, []);

  return (
    <div>
      <h2>Transaction History</h2>
      <ul>
        {transactions.map((transaction) => (
          <li key={transaction.id}>
            {transaction.type}: {transaction.amount}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TransactionList;
