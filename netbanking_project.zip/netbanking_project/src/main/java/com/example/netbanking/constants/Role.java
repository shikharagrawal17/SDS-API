package com.example.netbanking.constants;

// Role enum content here
