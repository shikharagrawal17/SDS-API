package com.example.netbanking.model;

// Account model content here
