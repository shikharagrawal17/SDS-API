package com.example.netbanking.model;

// Transaction model content here
