package com.example.netbanking.model;

// User model content here
