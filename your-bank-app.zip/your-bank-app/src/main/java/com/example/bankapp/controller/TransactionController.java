
package com.example.bankapp.controller;

import com.example.bankapp.service.TransactionService;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/transaction")
public class TransactionController {

    private final TransactionService transactionService;

    public TransactionController(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    @PostMapping("/deposit")
    public String deposit(@RequestParam Double amount, Authentication authentication) {
        String userId = authentication.getName();
        transactionService.deposit(userId, amount);
        return "Deposit successful";
    }

    @PostMapping("/withdraw")
    public String withdraw(@RequestParam Double amount, Authentication authentication) {
        String userId = authentication.getName();
        transactionService.withdraw(userId, amount);
        return "Withdrawal successful";
    }
}
