package com.bankapp.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Document(collection = "transactions")
public class Transaction {

    @Id
    private String id;
    private String fromUserId;
    private String toUserId;
    private double amount;
    private Date transactionDate;

    // Getters and setters...
}
